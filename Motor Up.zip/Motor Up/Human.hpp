#ifndef HUMAN_H
#define HUMAN_H

#include "Joueur.hpp"
#include <string.h>
#include <iostream>
#include <SFML/Graphics.hpp>
using namespace sf;

class Human : public Joueur
{
    struct Button1 {bool q, d, space;};
    struct Button2 {bool left, right, entrer;};

    private:
        // std::string name;
        Button1 button1;
        Button2 button2;
        float score;
        bool ingame;
        bool joueur1;       // Joueur1? ou Joueur2?

    public:
        Human();  
        Human(bool joueur2);
        void gestion_touche(Event event) override;
        bool commande_saut(Event event, Moto& moto) override;
        // std::string getName() const override;
        Button1 getButton1(void) const;
        Button2 getButton2(void) const;
        float getScore() const {return score;};
        void setScore(float tps) {score = tps;};
        bool getIngame() const {return ingame;};
        void SetIngame(bool game) {ingame = game;}; 
        bool getJoueur1() {return joueur1;};

};

#endif //HUMAN_H