#define BOOST_TEST_MODULE Test_MotorUp
#include <boost/test/included/unit_test.hpp>
#include "Moto.hpp"
#include "Fond.hpp"
#include "Obstacle.hpp"
#include "Human.hpp"

/* Classe Fond */ 

//Test du Constructeur pour vérifier que l'image est bien chargée
BOOST_AUTO_TEST_CASE(Test_Chargement_Images)
{
    Fond fond;

    BOOST_CHECK(fond.getSpritehome().getTexture()->getSize().x > 0);
    BOOST_CHECK(fond.getSpritehome().getTexture()->getSize().y > 0);
    BOOST_CHECK(fond.getSpritegame1().getTexture()->getSize().x > 0);
    BOOST_CHECK(fond.getSpritegame1().getTexture()->getSize().y > 0);
    BOOST_CHECK(fond.getSpritegame2().getTexture()->getSize().x > 0);
    BOOST_CHECK(fond.getSpritegame2().getTexture()->getSize().y > 0);
}

// Test que l'origine du bouton Play est bien au centre de celle-ci
BOOST_AUTO_TEST_CASE(Test_Origine_Bouton_Play)
{
    Fond fond;

    sf::Vector2u size = fond.getSpritehome().getTexture()->getSize();
    sf::Vector2f origin = fond.getSpritehome().getOrigin();

    BOOST_CHECK_EQUAL(origin.x, size.x/2);
    BOOST_CHECK_EQUAL(origin.y, size.y/2);
}



/* Classe Human */

// Test du constructeur de la classe Human (initialisation des variables à false)
BOOST_AUTO_TEST_CASE(TestInitialState)
{
    Human joueur1;
    Human joueur2{false};

    // Joueur1
    BOOST_CHECK(joueur1.getButton1().q == false);
    BOOST_CHECK(joueur1.getButton1().d == false);
    BOOST_CHECK(joueur1.getButton1().space == false);
    BOOST_CHECK(joueur1.getIngame() == false);
    BOOST_CHECK(joueur1.getJoueur1() == true);

    // Joueur2
    BOOST_CHECK(joueur2.getButton2().left == false);
    BOOST_CHECK(joueur2.getButton2().right == false);
    BOOST_CHECK(joueur2.getButton2().entrer == false);
    BOOST_CHECK(joueur2.getIngame() == false);
    BOOST_CHECK(joueur2.getJoueur1() == false);
}

// Test de la méthode gestion_touche
BOOST_AUTO_TEST_CASE(TestGestionTouche)
{
    Human joueur1;
    Human joueur2{false};

    // Simulation d'une touche de clavier appuyée
    sf::Event event;
    event.type = sf::Event::KeyPressed;
    event.key.code = sf::Keyboard::Q;
    joueur1.gestion_touche(event);
    BOOST_CHECK(joueur1.getButton1().q == true);

    event.key.code = sf::Keyboard::Right;
    joueur2.gestion_touche(event);
    BOOST_CHECK(joueur2.getButton2().right == true);

    event.key.code = sf::Keyboard::Space;
    joueur1.gestion_touche(event);
    BOOST_CHECK(joueur1.getButton1().space == true);

   // Simule lorsque la touche est relâchée
    event.type = sf::Event::KeyReleased;
    event.key.code = sf::Keyboard::Q;
    joueur1.gestion_touche(event);
    BOOST_CHECK(joueur1.getButton1().q == false);

    event.key.code = sf::Keyboard::Right;
    joueur2.gestion_touche(event);
    BOOST_CHECK(joueur2.getButton1().d == false);

    event.key.code = sf::Keyboard::Space;
    joueur1.gestion_touche(event);
    BOOST_CHECK(joueur1.getButton1().space == false);
}

//Test de la méthode commande_saut
BOOST_AUTO_TEST_CASE(Test_Commande_Saut)
{
    Human joueur1;
    Human joueur2{false};
    Moto moto;
    sf::Event event;    

    BOOST_CHECK(joueur1.commande_saut(event, moto) == false);

    event.type = sf::Event::KeyPressed;
    event.key.code = sf::Keyboard::Enter;
    BOOST_CHECK(joueur2.commande_saut(event, moto) == true);
}


/* Classe Moto*/

// Test du constructeur nous a semblé non pertinent de le faire

// Test de la méthode move
BOOST_AUTO_TEST_CASE(Test_Move_Moto)
{
    Moto moto;
    Human joueur1;
    Human joueur2(false);
    sf::Event event;    
    event.type = sf::Event::KeyPressed;

    // Simuler une pression sur la touche 'q' pour le joueur1
    event.key.code = sf::Keyboard::Q;
    joueur1.gestion_touche(event);
    moto.move(joueur1);
    BOOST_CHECK_EQUAL(moto.get_Angle1(), -72);

    // Simuler une pression sur la touche 'right' pour le joueur2
    event.key.code = sf::Keyboard::Right;
    joueur2.gestion_touche(event);
    moto.move(joueur2);
    BOOST_CHECK_EQUAL(moto.get_Angle2(), -68);
}

// Test de la méthode Jump (pas vraiment pertinent sans mettre en marche le jeu et la boucle while)
BOOST_AUTO_TEST_CASE(Test_Jump)
{
    Moto moto;
    Human joueur1;
    Human joueur2(false);

    // Simuler un saut pour le joueur 1
    moto.setJumping();
    joueur1.SetIngame(true);
    moto.jump(joueur1);
    BOOST_CHECK(moto.getJumping());

    // Simuler un saut pour le joueur 2
    moto.setJumping();
    moto.jump(joueur2);
    BOOST_CHECK(moto.getJumping());
}

// Test de la méthode reset_motos
BOOST_AUTO_TEST_CASE(Test_Reset_Motos)
{
    Moto moto;
    moto.setJumping();
    moto.reset_motos();
    BOOST_CHECK_EQUAL(moto.getJumping(), false);
    BOOST_CHECK_EQUAL(moto.get_Angle1(), -70);
    BOOST_CHECK_EQUAL(moto.get_Angle2(), -70);
}


/* Classe Obstacle */

// Test de la méthode move
BOOST_AUTO_TEST_CASE(Test_Move_Obstacle)
{
    Obstacle obstacle;
    Human joueur1, joueur2(false);
    float pos_init1 = obstacle.getSprite1().getPosition().x;
    float pos_init2 = obstacle.getSprite2().getPosition().x;

    // Simuler le déplacement des obstacles du joueur1
    obstacle.move(joueur1);
    BOOST_CHECK(obstacle.getSprite1().getPosition().x < pos_init1); // l'obstacle du joueur1 se déplace vers la gauche

    // Simuler le déplacement des obstacles du joueur2
    obstacle.move(joueur2);
    BOOST_CHECK(obstacle.getSprite2().getPosition().x < pos_init2); // l'obstacle du joueur2 se déplace vers la gauche
}

// Test de la méthode reset_obstacle (pas si pertinente, donc on a décidé de ne pas la tester)
// Test du constructeur nous a semblé non pertinent de le faire


/* 
Finalement étant donné que les classes restantes : Collisio, Interface_graphique et Jeu contiennent des méthodes requierant 
tous les 3 la gestion et le déroulement d'une fenêtre graphique avec tout le processus du Jeu.
Il était assez complexe de mettre des tests en place et que cela revenait tout simplement à tester le Jeu/Programme complet en lui-même.
*/
