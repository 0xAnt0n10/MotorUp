#ifndef MOTO_H
#define MOTO_H
#include "SFML/Graphics.hpp"
#include "iostream"
#include "Human.hpp"
#include "Collision.hpp"

using namespace sf;
using namespace std;

class Moto
{
    public:
        Moto();
        Sprite& getSprite1() {return sprite1;};
        Sprite& getSprite2() {return sprite2;};
        void move(Human& joueur);
        void jump(Human& joueur);
        void setJumping() {isjumping = true;};
        float getJumping() {return isjumping;};
        float get_Angle1() {return angle1;};
        void setAngle1(float value) {angle1 = value;};
        float get_Angle2() {return angle2;};
        void setAngle2(float value) {angle2= value;};
        void reset_motos();


    private:
        Texture texture1;       // Joueur1
        Sprite sprite1;     
        Texture texture2;       // Joueur2
        Sprite sprite2;
        float angle1;       // Inclinaison moto Joueur1
        float angle2;       // Inclinaison moto Joueur1
        bool isjumping;     // Détection d'un saut
        float jumpVelocity;
        float gravity;
        float deltaTime;
};

#endif //MOTO_H