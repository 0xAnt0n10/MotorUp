#ifndef INTERFACE_GRAPHIQUE_H
#define INTERFACE_GRAPHIQUE_H
#include "SFML/Graphics.hpp"
#include "SFML/Audio.hpp"
#include "iostream"
#include "Fond.hpp"
#include "Moto.hpp"
#include "Obstacle.hpp"

// Constantes du prog
const int WIN_WIDTH = 693*2;
const int WIN_HEIGHT = 490;

// Constante du prog
using namespace std;
using namespace sf;

class Obstacle; // Éviter les dépendances cyclique dû au fait que les deux fichier hpp sont l'un dans l'autre

class Interface_graphique
{
    public:
        Interface_graphique(Fond& fond, Obstacle& obstacle, Moto& moto1, Moto& moto2);
        void display_windows(); 
        
        void LoadFont();
        void SetText(Text& txt, String str);
        void load_game_over_j1();
        void load_game_over_j2();
        
        RenderWindow& getWindow(){return window;}
        
        Fond& getFond(){return fond;}
        void setFond(Fond& fond){this->fond=fond;}
        
        Obstacle& getObstacle(){return obstacle;}
        void getObstacle(Obstacle& obstacle) {this->obstacle=obstacle;}
        
        Moto& getMoto1(){return moto1;}
        void setMoto1(Moto&) {this->moto1=moto1;}
        
        Moto& getMoto2(){return moto2;}
        void setMoto2(Moto&) {this->moto2=moto2;}
        
        Text& getTxt1() {return txt1;};
        Text& getTxt2() {return txt2;};

        

    private:
        RenderWindow window;
        vector<Moto> moto;
        Font font;     
        // Création texte
        Text txt1;
        Text txt2;

        // Image Game over joueur 1
        Sprite sprite_game_over_j1;
        Texture texture_game_over_j1;

        // Image Game over joueur 2
        Sprite sprite_game_over_j2;
        Texture texture_game_over_j2;
        
        Fond fond;
        Obstacle obstacle;
        //Obstacle obstacle2;
        Moto moto1;
        Moto moto2;

};

#endif //INTERFACE_GRAPHIQUE_H
