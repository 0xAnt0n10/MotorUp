#ifndef JOUEUR_H
#define JOUEUR_H

#include "SFML/Graphics.hpp"
#include <string.h>
#include <iostream>

using namespace sf;

class Moto;

class Joueur
{
    public:
        virtual void gestion_touche(Event event) = 0;
        virtual bool commande_saut(Event event, Moto& moto) = 0;
        // virtual std::string getName() const= 0;

    private:
        // std::string name;
        float score;        // Résultat 
        bool ingame;        // Joueur en Jeu?
};

#endif //JOUEUR_H