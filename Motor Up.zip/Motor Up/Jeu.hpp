#ifndef JEU_HPP
#define JEU_HPP
#include "Joueur.hpp"
#include "Human.hpp"
#include "Interface_graphique.hpp"
#include "Collision.hpp"

class Jeu {
public:
    Jeu(Human& player1, Human& player2, bool game, Interface_graphique& window) : j1(player1), j2(player2), Game(game), interface(window) {}
    void jouer();
    void game_over();
    void stop_game();

private:
    Human& j1;      // Joueur j1; 
    Human& j2;      // Joueur j2;
    bool Game;      // Partie en cours?
    float score;
    Interface_graphique& interface;
    std::vector<std::vector<float>> classement;     // Résultat de la partie
};

#endif // JEU_HPP
