#ifndef POSITION_HPP
#define POSITION_HPP

class Position {
public:
    Position(float x, float y, float lo, float la): x(x), y(y), lo(lo), la(la){} ;
    const float& getX() const {return x; };
    const float& getY() const {return y; };
    const float& getLo() const {return lo; };
    const float& getYLa() const {return la; };
    
    void setX(float xx) {x=xx;};
    void setY(float yy) {y=yy;};
    void setLo(float l) {lo=l;};
    void setLa(float l) {la=l;};

private:
    float x;
    float y;
    float lo;
    float la;

};

#endif // POSITION_HPP

