#include "Obstacle.hpp"

Obstacle::Obstacle() 
{
    speed = 300.0f; // Pixels par seconde
    deltaTime = 1.0f / 60.0f; // Temps écoulé depuis la dernière frame (60 FPS)
    // Charger une image
    if(!texture1.loadFromFile("res/trash.png") || !texture2.loadFromFile("res/robot.png"))
    {
        cout << " Error loadind file" << endl;
        system("pause");
    }
    Collision::CreateTextureAndBitmask(texture1, "res/trash.png");
    sprite1.setTexture(texture1);
    sprite1.setPosition(693, 340.f);
    sprite1.setScale(0.5f, 0.5f);

    Collision::CreateTextureAndBitmask(texture2, "res/robot.png");
    sprite2.setTexture(texture2);
    sprite2.setPosition(693*2, 330.f);
    sprite2.setScale(0.2f, 0.2f);

    sprite_obstacle1 = sprite1;
    sprite_obstacle2 = sprite2;
}

void Obstacle::move(Human& joueur)
{
    float movement = speed * deltaTime;
    srand((unsigned int)time(0));
    int valeur  = rand()%2;
    
    // Déplacement de l'objet pour J1
    if(joueur.getJoueur1())
    {
        sprite1.move(-movement, 0);
        if (sprite1.getPosition().x + sprite1.getGlobalBounds().width/2 < 0)
        {
            if(valeur == 0) 
            {
                sprite1 = sprite_obstacle1;
                sprite1.setPosition(693-sprite1.getGlobalBounds().width, 340.f);

            }
            if(valeur == 1)
            {
                sprite1 = sprite_obstacle2;
                sprite1.setPosition(693-sprite1.getGlobalBounds().width, 330.f);
            }
        }
    }

    if(!joueur.getJoueur1())
    {
        // Déplacement de l'objet pour J2
        sprite2.move(-movement, 0);
        if (sprite2.getPosition().x < 693)
        {
            if(valeur == 0)
            {
                sprite2 = sprite_obstacle1;
                sprite2.setPosition(693*2, 340.f);
            }
            if(valeur == 1)
            {
                sprite2 = sprite_obstacle2;
            }
            if(speed<650)
                speed+=5;
        }
    }
}

void Obstacle::reset_obstacle()
{
    speed = 300.0f; // Pixels par seconde
    sprite1.setPosition(693-sprite1.getGlobalBounds().width, 340.f);
    sprite2.setPosition(693*2-sprite2.getGlobalBounds().width, 340.f);
    sprite1.setColor(Color::White);
    sprite2.setColor(Color::White);
}