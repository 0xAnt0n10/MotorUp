#include "Jeu.hpp"
#include <thread>
#include <chrono>

 void Jeu::jouer()
 {

    interface.display_windows();

    // Musique de fond
    SoundBuffer buffer;
    Sound sound;
    if(!buffer.loadFromFile("res/music.wav"))
    {
        cout << " Error loadind file" << endl;
        system("pause");
    }
    sound.setBuffer(buffer);
    sound.play();
    sound.setLoop(true); // Recommence la musique en boucle

    // Mise en place de Timmer
    Clock clock1;
    Clock clock2;

    // Charger fonte;
    interface.LoadFont();


    score=0;
    j1.setScore(score);
    j2.setScore(score);

    // Ligne de séparation de la fenêtre 
    RectangleShape line(Vector2f(5, 490));
    line.setFillColor(Color::Black);
    line.setPosition(693*2/2,0);

    while(interface.getWindow().isOpen())
    {
        // Evenements pour gérer la fenêtre
        Event event;
    
        while(interface.getWindow().pollEvent(event))
        {
            //ferme la fenêtre si la croiw est clické
            if(event.type == Event::Closed)
                interface.getWindow().close();

            // Gestion des inputs/events
            if(event.type == Event::KeyPressed) 
            {
                if(event.key.code == Keyboard::A)
                    interface.getWindow().close();
            }
            if(Game)
            {
                if(j1.getIngame())  // Le joueur 2 est en Jeu 
                    j1.gestion_touche(event);
                if(j2.getIngame())  // Le joueur 2 est en Jeu 
                    j2.gestion_touche(event);
            }

            interface.getMoto1().move(j1);
            interface.getMoto2().move(j2);
            j1.commande_saut(event, interface.getMoto1());
            j2.commande_saut(event, interface.getMoto2());

            // Gestion boutton play/click souris
            if (event.type == sf::Event::MouseMoved)
            {
                // Vérifier si la souris est sur le rectangle
                if (interface.getFond().getSpritehome().getGlobalBounds().contains(event.mouseMove.x, event.mouseMove.y))
                {
                    // Changer la taille du rectangle
                    interface.getFond().getSpritehome().setScale(0.6, 0.6);
                }
                else
                {
                    // Revenir à la taille normale du rectangle
                    interface.getFond().getSpritehome().setScale(0.5, 0.5);
                }
            }
            // Gestion du clic de la souris
            if (event.type == sf::Event::MouseButtonPressed && !j1.getIngame() && !j2.getIngame() &&!Game)
            {
                // Vérifier si le clic est dans la zone du rectangle
                if (event.mouseButton.button == sf::Mouse::Left &&
                    interface.getFond().getSpritehome().getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y))
                {
                    // std::cout << "Clic détecté dans la zone !" << std::endl;
                    j1.SetIngame(true);
                    j2.SetIngame(true);
                    Game = true;
                    clock2.restart();
                }
            }
            
        }

        // Mettre ici tout les éléments du jeu à dessiner (général)
        interface.getWindow().clear();
        interface.getWindow().draw(interface.getFond().getSpritegame1());
        interface.getWindow().draw(interface.getFond().getSpritegame2());
        interface.getWindow().draw(interface.getMoto1().getSprite1());
        interface.getWindow().draw(interface.getMoto2().getSprite2());
        interface.getWindow().draw(interface.getObstacle().getSprite1());
        interface.getWindow().draw(interface.getObstacle().getSprite2());
        // interface.getWindow().draw(originPoint);
        interface.getWindow().draw(line);
        interface.getWindow().draw(interface.getTxt1());
        interface.getWindow().draw(interface.getTxt2());
           
        


        if(Game)
        {
            if(j1.getIngame())  // Le joueur 1 est en Jeu 
            {   
                if(interface.getMoto1().get_Angle1()<0)
                    interface.getMoto1().setAngle1(interface.getMoto1().get_Angle1()+0.1); // simulation gravite pour l'équilibre de j1
                
                if(interface.getMoto1().get_Angle1()>=-15 || interface.getMoto1().get_Angle1()<=-70)
                {
                    interface.getMoto1().getSprite1().setColor(sf::Color(255, 0, 0));
                    interface.getWindow().draw(interface.getMoto1().getSprite1());
                    interface.getMoto1().getSprite1().setColor(sf::Color(255, 255, 255));
                    Text warning1;
                    interface.SetText(warning1, "Warning !");
                    warning1.setFillColor(Color::Red);
                    warning1.setPosition(WIN_WIDTH/5, WIN_HEIGHT/3);
                    interface.getWindow().draw(warning1);

                }

                interface.getMoto1().getSprite1().setRotation(interface.getMoto1().get_Angle1());
                interface.getMoto1().jump(j1);
                interface.getObstacle().move(j1);

                // Écoulement du temps 
                Time elapsed = clock2.getElapsedTime();
                //cout << " Time J1" << elapsed.asSeconds() << endl;
                interface.SetText(interface.getTxt1(), to_string(elapsed.asSeconds()));
                interface.getTxt1().setPosition(2*WIN_WIDTH/5, 0);
                score=elapsed.asSeconds();
               j1.setScore(score);
                
                
                // if (interface.getMoto1().getSprite1().getGlobalBounds().intersects(interface.getObstacle().getSprite1().getGlobalBounds()))
                // Gestion des collisions aux pixels près
                if (Collision::PixelPerfectTest(interface.getMoto1().getSprite1(), interface.getObstacle().getSprite1()) || interface.getMoto1().get_Angle1()>=0 || interface.getMoto1().get_Angle1()<=-85)
                {
                    //cout << "Collision J1!" << endl;
                    j1.SetIngame(false);
                    interface.getMoto1().getSprite1().setColor(sf::Color(255, 0, 0));
                    interface.getObstacle().getSprite1().setColor(sf::Color(255, 0, 0));
                }
                else 
                {
                    //cout << "No collision J1!" << endl;
                }
            }

            if(j2.getIngame())  // Le joueur 2 est en Jeu 
            {   
                if(interface.getMoto2().get_Angle2()<0)
                    interface.getMoto2().setAngle2(interface.getMoto2().get_Angle2()+0.1); // simulation gravite pour l'équilibre de j2
                
                if(interface.getMoto2().get_Angle2()>=-15 || interface.getMoto2().get_Angle2()<=-70)
                {
                    interface.getMoto2().getSprite2().setColor(sf::Color(255, 0, 0));
                    interface.getWindow().draw(interface.getMoto2().getSprite2());
                    interface.getMoto2().getSprite2().setColor(sf::Color(255, 255, 255));
                    Text warning2;
                    interface.SetText(warning2, "Warning !");
                    warning2.setFillColor(Color::Red);
                    warning2.setPosition(WIN_WIDTH/5+WIN_WIDTH/2, WIN_HEIGHT/3);
                    interface.getWindow().draw(warning2);
                }

                interface.getMoto2().getSprite2().setRotation(interface.getMoto2().get_Angle2());
                interface.getMoto2().jump(j2);
                interface.getObstacle().move(j2);

                // Écoulement du temps 
                Time elapsed = clock2.getElapsedTime();
                //cout << " Time J2" << elapsed.asSeconds() << endl;
                interface.SetText(interface.getTxt2(), to_string(elapsed.asSeconds()));
                interface.getTxt2().setPosition(2*WIN_WIDTH/5+WIN_WIDTH/2, 0);
                score=elapsed.asSeconds();
                j2.setScore(score);

                // if (interface.getMoto2().getSprite2().getGlobalBounds().intersects(interface.getObstacle().getSprite2().getGlobalBounds()))
                if (Collision::PixelPerfectTest(interface.getMoto2().getSprite2(), interface.getObstacle().getSprite2()) || interface.getMoto2().get_Angle2()>=0 || interface.getMoto2().get_Angle2()<=-85)
                {
                    //cout << "Collision J2!" << endl;
                    j2.SetIngame(false);
                    interface.getMoto2().getSprite2().setColor(sf::Color(255, 0, 0));
                    interface.getObstacle().getSprite2().setColor(sf::Color(255, 0, 0));
                }
                else 
                {
                    //cout << "No collision J2!" << endl;
                }
            }
            
            game_over(); // Affichage du game over et score

        }
        // Menu du Jeu
        else 
        {
            interface.getWindow().draw(interface.getFond().getSpritegame1());
            interface.getWindow().draw(interface.getFond().getSpritegame2());
            interface.getWindow().draw(interface.getFond().getSpritehome());
            // window.draw(rect);
            // window.draw(txt);
        }
        interface.getWindow().display();
    }
}


void Jeu::game_over()
{
    Texture texture_go;
    Sprite sprite_go;
    if(!texture_go.loadFromFile("res/Game_over.png")) 
    {
        cout << " Error loadind file" << endl;
        system("pause");
    }
    sprite_go.setTexture(texture_go);
    sprite_go.setOrigin(texture_go.getSize().x/2, texture_go.getSize().y/2);

    if (!j1.getIngame())
    {  
        sprite_go.setPosition(WIN_WIDTH/4, WIN_HEIGHT/2);
        interface.getWindow().draw(sprite_go);
        interface.SetText(interface.getTxt1(), to_string(j1.getScore()));
        interface.getTxt1().setPosition(WIN_WIDTH/4, WIN_HEIGHT/2);
        interface.getWindow().draw(interface.getTxt1());
    }
    if (!j2.getIngame())
    {
        sprite_go.setPosition(3*WIN_WIDTH/4, WIN_HEIGHT/2);
        interface.getWindow().draw(sprite_go);
        interface.SetText(interface.getTxt2(), to_string(j2.getScore()));
        interface.getTxt2().setPosition(WIN_WIDTH/4+WIN_WIDTH/2, WIN_HEIGHT/2);
        interface.getWindow().draw(interface.getTxt2());
    }
    if(!j2.getIngame() && !j1.getIngame())
    {   
        stop_game();         
        /* A décommenter pour la version "replay" */
        // interface.getMoto1().reset_motos();
        // interface.getMoto2().reset_motos();
        // interface.getObstacle().reset_obstacle();
    }
}

void Jeu::stop_game()
{    
    Texture texture_win;
    Sprite sprite_win;
    if(!texture_win.loadFromFile("res/Winner.png")) 
    {
        cout << " Error loading file" << endl;
        system("pause");
    }
    sprite_win.setTexture(texture_win);
    sprite_win.setOrigin(texture_win.getSize().x/2, texture_win.getSize().y/2);

    if (j1.getScore()> j2.getScore()+1)
    {
        sprite_win.setPosition(WIN_WIDTH/4, WIN_HEIGHT/2);
        interface.getWindow().draw(sprite_win);
        interface.SetText(interface.getTxt1(), to_string(j1.getScore()));
        interface.getTxt1().setPosition(WIN_WIDTH/4, WIN_HEIGHT/2);
        interface.getWindow().draw(interface.getTxt1());
        //while(true){}
    }
    if (j2.getScore()> j1.getScore()+1)
    {
        sprite_win.setPosition(3*WIN_WIDTH/4, WIN_HEIGHT/2);
        interface.getWindow().draw(sprite_win);    
        interface.SetText(interface.getTxt2(), to_string(j2.getScore()));
        interface.getTxt2().setPosition(WIN_WIDTH/4+WIN_WIDTH/2, WIN_HEIGHT/2);
        interface.getWindow().draw(interface.getTxt2());
    }


    classement.push_back({j1.getScore(),j2.getScore()} );
    
    for(int i=0;i< (int) classement.size();i++){
		for(int j=0;j< (int) classement[i].size();j++)
			cout<< "Score : " << classement[i][j] << " ";
		    cout<<endl;
	}
	
    float best_score1=0;
    float best_score2=0;
    float best_score;
    char bs[6];
    for (int i = 0; i < (int) classement.size(); i++)
    {
    if(classement[i][0]>best_score1) {best_score1=classement[i][0];}
    if(classement[i][1]>best_score2) {best_score2=classement[i][1];}
    
    }
    
    if(best_score1>best_score2) {best_score=best_score1; strcpy(bs,"J1");}
    else if (best_score2>best_score1){best_score=best_score2; strcpy(bs,"J2");}
    else if (best_score1==best_score2){best_score=0; strcpy(bs,"J1 J2");}
    

    for (int a=0; a<1000000;a++)
    {
        for (int i = 0; i < (int) classement.size(); i++){ 
        /*cout <<  classement[i][0] << endl;
        cout <<  classement[i][1] << endl;*/
        
        /*interface.SetText(interface.getTxtclassement(), to_string(classement[i][0]));
        interface.getTxtclassement().setPosition(2*WIN_WIDTH/6, 2*WIN_HEIGHT/5);
        interface.getWindow().draw(interface.getTxtclassement());*/
        } 
    }
    /* A décommenter pour la version "replay" */
    // std::this_thread::sleep_for(std::chrono::seconds(3));
    // Game = false;
}
