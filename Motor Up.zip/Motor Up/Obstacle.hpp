#ifndef OBSTACLE_H
#define OBSTACLE_H
#include "SFML/Graphics.hpp"
#include "iostream"
#include "Human.hpp"
#include "Collision.hpp"
using namespace sf;
using namespace std;

class Obstacle
{
    public:
        Obstacle();
        Sprite& getSprite1() {return sprite1;};
        Sprite& getSprite2() {return sprite2;};
        void move(Human& joueur);
        void reset_obstacle();

    private:
        Texture texture1;       // Obstacle Joueur1
        Sprite sprite1;
        Texture texture2;       // Obstacle Joueur2
        Sprite sprite2;
        Sprite sprite_obstacle1, sprite_obstacle2;      // Sprite de stockage
        float speed;
        float deltaTime;
};

#endif //OBSTACLE_H