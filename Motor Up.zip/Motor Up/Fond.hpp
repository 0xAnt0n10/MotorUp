#ifndef FOND_H
#define FOND_H
#include "SFML/Graphics.hpp"
#include "iostream"

using namespace sf;
using namespace std;

class Fond
{
    public:
        Fond();
        Sprite& getSpritehome() {return sprite_home;};
        Sprite& getSpritegame1() {return sprite_game1;};
        Sprite& getSpritegame2() {return sprite_game2;};


    private:
        Texture texture_home;    // Bouton play
        Sprite sprite_home;     
        Texture texture_game1;      // Fond J1
        Sprite sprite_game1;
        Texture texture_game2;      // Fond J2
        Sprite sprite_game2;
};

#endif //FOND_H