#include "Fond.hpp"

Fond::Fond()
{
    // Charger une image
    if(!texture_home.loadFromFile("res/play_button.png") || !texture_game1.loadFromFile("res/fond.jpg") || !texture_game2.loadFromFile("res/fond.jpg"))  
    {
        cout << " Error loadind file" << endl;
        system("pause");
    }
    sprite_home.setTexture(texture_home);
    sprite_home.setOrigin(texture_home.getSize().x/2, texture_home.getSize().y/2);

    sprite_game1.setTexture(texture_game1);
    sprite_game2.setTexture(texture_game2);
}