#include "Moto.hpp"

Moto::Moto()
{
    angle1 = -70;
    angle2 = -70;
    isjumping = false;
    jumpVelocity = -500.0f; // Vitesse initiale du saut (pixels par seconde)
    gravity = 1000.0f; // Gravité (pixels par seconde carré)
    deltaTime = 1.0f / 60.0f; // Temps écoulé depuis la dernière frame (60 FPS)

    // Charger une image
    if(!texture1.loadFromFile("res/moto.png") || !texture2.loadFromFile("res/moto.png")) 
    {
        cout << " Error loadind file" << endl;
        system("pause");
    }
    Collision::CreateTextureAndBitmask(texture1, "res/moto.png");
    sprite1.setTexture(texture1);
    sprite1.setPosition(150.f, 400);
    sprite1.setOrigin(20, 120);

    Collision::CreateTextureAndBitmask(texture2, "res/moto.png");
    sprite2.setTexture(texture2);
    sprite2.setPosition(150.f+693, 400);
    sprite2.setOrigin(20, 120);

    /* lisser texture pour une meilleure qualité */
    texture1.setSmooth(true);
    texture2.setSmooth(true);
}

void Moto::move(Human& joueur)
{
    if(joueur.getJoueur1())
    {
        if(joueur.getButton1().q) 
        {
            this->angle1 -= 2;
            if(this->angle1 <= -90)
                this->angle1 =-90;   
        }
        if(joueur.getButton1().d)
        {
            this->angle1 += 2;
            if(this->angle1 >= -10)
                this->angle1 = -10; 
        }
        sprite1.setRotation(this->angle1);
    }
    else
    {
        if(joueur.getButton2().left)
        {
            this->angle2 -= 2;
            if(this->angle2 <= -90)
                this->angle2 =-90;
        }
        if(joueur.getButton2().right)
        {
            this->angle2 += 2;
            if(this->angle2 >= -10)
                this->angle2 = -10;  
        }
        sprite2.setRotation(this->angle2); 
    }
}

void Moto::jump(Human& joueur)
{
    if(isjumping)
    {
        if(joueur.getJoueur1())
        {
            sprite1.move(0, jumpVelocity*deltaTime);
            jumpVelocity +=gravity*deltaTime;
            if (sprite1.getPosition().y >= 400.f)
            {
                sprite1.setPosition(sprite1.getPosition().x, 400.f);
                isjumping = false;
                jumpVelocity = -500.0f; // Réinitialiser la vélocité de saut pour le prochain saut
            }
        }

        if(!joueur.getJoueur1())
        {
            sprite2.move(0, jumpVelocity*deltaTime);
            jumpVelocity +=gravity*deltaTime;
            if (sprite2.getPosition().y >= 400.f)
            {
                sprite2.setPosition(sprite2.getPosition().x, 400.f);
                isjumping = false;
                jumpVelocity = -500.0f; // Réinitialiser la vélocité de saut pour le prochain saut
            }
        }
    }
}

void Moto::reset_motos()
{
    isjumping = false;
    setAngle1(-70);
    setAngle2(-70);
    sprite1.setRotation(angle1);
    sprite2.setRotation(angle2);
    sprite1.setColor(Color::White);
    sprite1.setPosition(150.f, 400);
    sprite2.setColor(Color::White);
    sprite2.setPosition(150.f+693, 400);
}   