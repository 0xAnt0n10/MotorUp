#include "Human.hpp"
#include "Interface_graphique.hpp"

// Constructeur
Human::Human()
{
    button1.q = button1.d = button1.space = ingame = false;
    this->joueur1 = true;
}

// Constructeur
Human::Human(bool joueur2)
{
   button2.left = button2.right = button2.entrer = ingame = false;
   this->joueur1 = joueur2;
}

Human::Button1 Human::getButton1(void) const
{
    return button1;
}

Human::Button2 Human::getButton2(void) const
{
    return button2;
}


// Gestionnaires des inputs
void Human::gestion_touche(Event event)
{
    // Gestion inputs (clavier)
    if(event.type == Event::KeyPressed)
    {
        switch (event.key.code)
        {
        case Keyboard::Left:
            button2.left = true;
            break;
        case Keyboard::Right:
            button2.right = true;
            break;
        case Keyboard::Enter:
            button2.entrer = true;
            break;
        case Keyboard::Q:
            button1.q = true;
            break;
        case Keyboard::D:
            button1.d = true;
            break;
        case Keyboard::Space:
            button1.space = true;
            break;
        default:
            break;
        }
    }

    if(event.type == Event::KeyReleased)
    {
        switch (event.key.code)
        {
        case Keyboard::Left:
            button2.left = false;
            break;
        case Keyboard::Right:
            button2.right = false;
            break;
        case Keyboard::Enter:
            button2.entrer = false;
            break;
        case Keyboard::Q:
            button1.q = false;
            break;
        case Keyboard::D:
            button1.d = false;
            break;
        case Keyboard::Space :
            button1.space = false;
            break;
        default:
            break;
        }
    }
}

bool Human::commande_saut(Event event, Moto& moto)
{
     // Gestion inputs (clavier)
    if(event.type == Event::KeyPressed)
    {
        if(joueur1 == true && event.key.code == Keyboard::Space)
        {
            moto.setJumping();
        }
        if(joueur1 == false && event.key.code == Keyboard::Enter)
        {
            moto.setJumping();
        }

    }
    return moto.getJumping();
}

// std::string Human::getName() const
// {
//     return name;
// }