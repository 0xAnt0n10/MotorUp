#include "Interface_graphique.hpp"

Interface_graphique::Interface_graphique(Fond& fond, Obstacle& obstacle, Moto& moto1, Moto& moto2) : fond(fond), obstacle(obstacle), moto1(moto1),
moto2(moto2){
    // Def des options
    ContextSettings options;
    options.antialiasingLevel = 8;  // Lissage des formes
    
    // Créer une fenêtre plus développée 
    window.create(sf::VideoMode(WIN_WIDTH,WIN_HEIGHT), "Motor Up", Style::Default, options);
    
    // Synchronisation du taux de raffraichissement 
    window.setVerticalSyncEnabled(true);
}
        
void Interface_graphique::display_windows()
{
    // Arrière fond du joueur1
    fond.getSpritehome().setScale(0.5, 0.5);
    fond.getSpritehome().setPosition(WIN_WIDTH/2, WIN_HEIGHT/2);

    // Arrière fond du joueur2 
    fond.getSpritegame2().setPosition(WIN_WIDTH/2, 0);
}

void Interface_graphique::LoadFont()
{
    // Police bien chargée ?
    if(!font.loadFromFile("res/Poppins.ttf"))
        cout << "Erreur de chargement de fonte" << endl;
}


void Interface_graphique::SetText(Text& txt, String str)
{
    // Indique la police
    txt.setFont(font);
    // Indice le caractère
    txt.setString(str);
    // indique la taille
    txt.setCharacterSize(20);
    // indique la couleur
    txt.setFillColor(Color::Black);
    // indique le style
    txt.setStyle(Text::Regular |Text::Italic);
}

void Interface_graphique::load_game_over_j1()
{
    // Charger une image
    if(!texture_game_over_j1.loadFromFile("res/play_button.png"))
    {
        cout << " Error loadind file" << endl;
        system("pause");
    }
    sprite_game_over_j1.setTexture(texture_game_over_j1);
    sprite_game_over_j1.setPosition(2*WIN_WIDTH/5,WIN_HEIGHT/2);
}

void Interface_graphique::load_game_over_j2()
{
    // Charger une image
    if(!texture_game_over_j2.loadFromFile("res/play_button.png"))
    {
        cout << " Error loadind file" << endl;
        system("pause");
    }
    sprite_game_over_j2.setTexture(texture_game_over_j2);
    sprite_game_over_j2.setPosition(4*WIN_WIDTH/5,WIN_HEIGHT/2);
}
