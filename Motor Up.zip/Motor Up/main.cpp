#include "Jeu.hpp"
#include "Fond.hpp"
#include "Obstacle.hpp"
#include "Moto.hpp"


int main() 
{
    Human j1;
    Human j2(false);
    
    Fond fond;
    Obstacle poubelle1;
    
    Moto moto1;
    Moto moto2;
    
    Interface_graphique interface(fond, poubelle1, moto1, moto2);
    Jeu jeu(j1, j2, false, interface);
    jeu.jouer();
    return 0;
}

